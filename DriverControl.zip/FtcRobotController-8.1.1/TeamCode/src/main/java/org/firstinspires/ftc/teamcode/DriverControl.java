package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

//adb connect 192.168.43.1

@TeleOp(name = "Driver Control", group = "Linear Opmode")
public class DriverControl extends LinearOpMode {
    // Declare OpMode members
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor frontLeft;
    private DcMotor frontRight;
    private DcMotor backLeft;
    private DcMotor backRight;
    private DcMotor towerYaxis1;
    private DcMotor towerYaxis2;
    private Servo claw;
    //private Servo claw2;

    @Override
    public void runOpMode() {

        telemetry.addData("Status", "Running");
        telemetry.update();
        frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
        frontRight = hardwareMap.get(DcMotor.class, "frontRight");
        backLeft = hardwareMap.get(DcMotor.class, "backLeft");
        backRight = hardwareMap.get(DcMotor.class, "backRight");
        towerYaxis1 = hardwareMap.get(DcMotor.class, "towerYaxis1");
        towerYaxis2 = hardwareMap.get(DcMotor.class, "towerYaxis2");
        claw = hardwareMap.get(Servo.class, "claw");

        frontRight.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.REVERSE);
        claw.setDirection(Servo.Direction.REVERSE);

        waitForStart();
        runtime.reset();

        while (opModeIsActive()) {

            double drive = -gamepad1.left_stick_y/2;
            double strafe = gamepad1.left_stick_x/2;
            double turn = gamepad1.right_stick_x/2;

            double frontLeftPower = Range.clip(drive + strafe + turn, -1.0, 1.0);
            double frontRightPower = Range.clip(drive - strafe - turn, -1.0, 1.0);
            double backLeftPower = Range.clip(drive - strafe + turn, -1.0, 1.0);
            double backRightPower = Range.clip(drive + strafe - turn, -1.0, 1.0);

            frontLeft.setPower(frontLeftPower);
            frontRight.setPower(frontRightPower);
            backLeft.setPower(backLeftPower);
            backRight.setPower(backRightPower);
            towerYaxis1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            towerYaxis2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);



            if(gamepad1.dpad_up){
                towerYaxis2.setPower(1); //FIX direction
                towerYaxis1.setPower(-1);
            }
//            else
//            {
//                towerYaxis1.setPower(0);
//                towerYaxis2.setPower(0);
//            }

            if(gamepad1.dpad_down){
                towerYaxis2.setPower(-1); //FIX direction
                towerYaxis1.setPower(1);
            }
//            else
//            {
//                towerYaxis1.setPower(0);
//                towerYaxis2.setPower(0);
//            }


            while(gamepad1.right_bumper){ //closes
                claw.setPosition(claw.getPosition() - 0.005);
                //claw2.setPosition(claw2.getPosition() + 0.005);
            }

            while(gamepad1.left_bumper) {
                claw.setPosition(claw.getPosition() + 0.005);
                //claw2.setPosition(claw2.getPosition() - 0.005);
            }


            // Show the elapsed game time and wheel power.
            telemetry.addData("Status", "Run Time: " + runtime.toString());
            telemetry.addData("Claw Position",  claw.getPosition());
            //telemetry.addData("Claw2 Position",  claw2.getPosition());
            telemetry.addData("TowerYaxis1 Position", towerYaxis1.getCurrentPosition());
            telemetry.addData("TowerYaxis2 Position", towerYaxis2.getCurrentPosition());
            telemetry.update();
        }

    }

}
//LEFT SLIDE MOTOR NOT WORKING TOWERYAXIS1
// Need code for moving arm side to side
// Need code for close and opening claw (left and right button)